﻿using System.Windows;
using AntragsVerwaltung.Common;
using AntragsVerwaltung.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Net.Http;

namespace AntragsVerwaltung.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<AntragItem> _Liste;
        private ICommand _OkCommand;
        private int _SelectedAntragId = 0;
        private Visibility _ButtonVisibility;

        public Visibility ButtonVisibility
        {
            get { return SelectedAntragId > 0 ? Visibility.Visible : Visibility.Hidden; }
        }

        public int SelectedAntragId
        {
            get { return _SelectedAntragId; }
            set
            {
                _SelectedAntragId = value;
                PropertyChanged(this, new PropertyChangedEventArgs("SelectedAntragId"));
                PropertyChanged(this, new PropertyChangedEventArgs("ButtonVisibility"));
            }
        }

        public ObservableCollection<AntragItem> Liste
        {
            get { return _Liste; }
            set
            {
                _Liste = value;
                if (PropertyChanged != null)
                {
                    PropertyChanged(this, new PropertyChangedEventArgs("Liste"));
                }
            }
        }

        public ICommand OkCommand
        {
            get
            {
                if (_OkCommand == null)
                {
                    _OkCommand = new RelayCommand((parameter) => Confirm((int)parameter));
                }
                return _OkCommand;
            }
            set
            {
                _OkCommand = value;
                PropertyChanged(this, new PropertyChangedEventArgs("Liste"));
            }
        }

        public MainViewModel()
        {
            bool inDesigner = true; // DesignerProperties.GetIsInDesignMode(new DependencyObject());
            if (inDesigner)
            {
                LoadDataForDesigner();
            }
            else
            {
                LoadData();
            }
            if (_Liste.Count > 0)
            {
                _SelectedAntragId = _Liste[0].AntragId;
            }
        }

        private void LoadDataForDesigner()
        {
            var liste = new List<AntragItem>()
            {
                new AntragItem() { AntragId=12, FormData="{\"mandantId\":101,\"datenbankId\":1,\"datum\":\"17.12.2014 11:28:40\",\"absender\":\"41796827023\", \"mandantBezeichnung\":\"Gemeinde X\",\"datenbankBezeichnung\":\"Unique\", \"items\":[{\"status\":\"modified\",\"handyNummer\":\"41792706824\",\"shortName\":\"ags\",\"vorname\":\"Peter\",\"name\":\"Henrici\",\"isAdmin\":\"on\",\"isGesperrt\":\"on\"}, {\"status\":\"modified\",\"handyNummer\":\"41792706824\",\"shortName\":\"stfe\",\"vorname\":\"Peter\",\"name\":\"Henrici\",\"isAdmin\":\"on\",\"isGesperrt\":\"off\"}]}" },
                new AntragItem() { AntragId=13, FormData="{\"mandantId\":102,\"datenbankId\":1,\"datum\":\"19.12.2014 12:19:30\",\"absender\":\"41792270683\", \"mandantBezeichnung\":\"Gemeinde A\",\"datenbankBezeichnung\":\"HHRR\", \"items\":[{\"status\":\"added\",\"handyNummer\":\"41792706824\",\"shortName\":\"stfe\",\"vorname\":\"Peter\",\"name\":\"Henrici\",\"isAdmin\":\"on\",\"isGesperrt\":\"off\"}]}" },
                new AntragItem() { AntragId=14, FormData="{\"mandantId\":103,\"datenbankId\":2,\"datum\":\"21.12.2014 09:07:06\",\"absender\":\"41760682231\", \"mandantBezeichnung\":\"Gemeinde F\",\"datenbankBezeichnung\":\"DB2\", \"items\":[{\"status\":\"modified\",\"handyNummer\":\"41792706824\",\"shortName\":\"dzz\",\"vorname\":\"Peter\",\"name\":\"Henrici\",\"isAdmin\":\"on\",\"isGesperrt\":\"off\"}, {\"status\":\"modified\",\"handyNummer\":\"41792706824\",\"shortName\":\"stfe\",\"vorname\":\"Peter\",\"name\":\"Henrici\",\"isAdmin\":\"on\",\"isGesperrt\":\"off\"}, {\"status\":\"modified\",\"handyNummer\":\"41793353202\",\"shortName\":\"stfe2\",\"vorname\":\"Peter\",\"name\":\"Henrici\",\"isAdmin\":\"on\",\"isGesperrt\":\"on\"}, {\"status\":\"modified\",\"handyNummer\":\"41792706824\",\"shortName\":\"stfe\",\"vorname\":\"Peter\",\"name\":\"Henrici\",\"isAdmin\":\"on\",\"isGesperrt\":\"on\"}]}" },
                new AntragItem() { AntragId=15, FormData="{\"mandantId\":104,\"datenbankId\":1,\"datum\":\"21.12.2014 15:29:53\",\"absender\":\"41786823270\", \"mandantBezeichnung\":\"Gemeinde B\",\"datenbankBezeichnung\":\"Datenbank342\", \"items\":[{\"status\":\"modified\",\"handyNummer\":\"41792706824\",\"shortName\":\"ioo\",\"vorname\":\"Peter\",\"name\":\"Henrici\",\"isAdmin\":\"off\",\"isGesperrt\":\"on\"}, {\"status\":\"modified\",\"handyNummer\":\"41792706824\",\"shortName\":\"stfe\",\"vorname\":\"Peter\",\"name\":\"Henrici\",\"isAdmin\":\"on\",\"isGesperrt\":\"off\"}, {\"status\":\"modified\",\"handyNummer\":\"41793353202\",\"shortName\":\"stfe2\",\"vorname\":\"Peter\",\"name\":\"Henrici\",\"isAdmin\":\"on\",\"isGesperrt\":\"on\"}, {\"status\":\"modified\",\"handyNummer\":\"41792706824\",\"shortName\":\"stfe\",\"vorname\":\"Peter\",\"name\":\"Henrici\",\"isAdmin\":\"on\",\"isGesperrt\":\"on\"}, {\"status\":\"modified\",\"handyNummer\":\"41792706824\",\"shortName\":\"stfe\",\"vorname\":\"Peter\",\"name\":\"Henrici\",\"isAdmin\":\"on\",\"isGesperrt\":\"on\"}]}" }
            };
            Liste = new ObservableCollection<AntragItem>(liste);
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private async void LoadData()
        {
            var httpClient = new HttpClient();
            using (httpClient)
            {
                httpClient.DefaultRequestHeaders.Add("user-agent",
                    "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)");
                var response =
                    await httpClient.GetAsync(new Uri("http://localhost:81/Admin/GetAntraege", UriKind.Absolute));
                response.EnsureSuccessStatusCode();
                var result = await response.Content.ReadAsStringAsync();
                var bytes = Encoding.Unicode.GetBytes(result);
                using (var stream = new MemoryStream(bytes))
                {
                    var serializer = new DataContractJsonSerializer(typeof (List<AntragItem>));
                    var liste = (List<AntragItem>)serializer.ReadObject(stream);
                    Liste = new ObservableCollection<AntragItem>(liste);
                }
            }
        }

        private async void Confirm(int antragId)
        {
            MessageBoxResult dr = MessageBox.Show("Wollen sie den Antrag (" + antragId + ") wirklich abschicken?", "Bestätigung", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (dr != MessageBoxResult.Yes)
            {
                return;
            }
            bool inDesigner = true; // DesignerProperties.GetIsInDesignMode(new DependencyObject());
            if (!inDesigner)
            {
                var httpClient = new HttpClient();
                using (httpClient)
                {
                    httpClient.DefaultRequestHeaders.Add("user-agent",
                        "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)");
                    var uri = "http://localhost:81/Admin/ConfirmAntrag?antragId=" + antragId;
                    var response =
                        await httpClient.GetAsync(new Uri(uri, UriKind.Absolute));
                    response.EnsureSuccessStatusCode();
                    var result = await response.Content.ReadAsStringAsync();
                    AntragItem itemToRemove = null;
                    if (result == "ok")
                    {
                        foreach (var item in _Liste)
                        {
                            if (item.AntragId == antragId)
                            {
                                itemToRemove = item;
                            }
                        }
                        if (itemToRemove != null)
                        {
                            _Liste.Remove(itemToRemove);
                        }
                    }
                    else
                    {
                        // Buhhh
                    }
                }
            }
            else
            {
                AntragItem itemToRemove = null;
                foreach (var item in _Liste)
                {
                    if (item.AntragId == antragId)
                    {
                        itemToRemove = item;
                    }
                }
                if (itemToRemove != null)
                {
                    _Liste.Remove(itemToRemove);
                }
            }
            if (_Liste.Count > 0)
            {
                SelectedAntragId = _Liste[0].AntragId;
            }
        }
    }
}
